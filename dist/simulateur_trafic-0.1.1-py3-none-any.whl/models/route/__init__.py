"""Route package exposing the road entity used in simulations."""

from .route import Route

__all__ = ["Route"]
