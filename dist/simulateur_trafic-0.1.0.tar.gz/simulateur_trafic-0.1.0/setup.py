from setuptools import setup, find_packages

setup(
    name="simulateur_trafic",
    author="Dhia BEN HAMOUDA",
    author_email="dhiabenhamouda2002@gmail.com",
    description="Un simulateur de trafic pour étudier les comportements des véhicules.",
    version="0.1.0",
    packages=find_packages(),
)