# Test logique en utilisant Pytest
Poetry add pytest