"""Affichage package exposing console and chart renderers."""

from .affichage import Affichage

__all__ = ["Affichage"]
