"""Analyse package exposing metrics computation helpers."""

from .analyseur import Analyseur

__all__ = ["Analyseur"]
